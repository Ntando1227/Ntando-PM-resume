"""Generate a filterable Excel report from the SQLite reporting database (artifact_tool)."""
from artifact_tool import Workbook,SpreadsheetFile
import sqlite3,csv,pathlib
root=pathlib.Path(__file__).parent;con=sqlite3.connect(root/'output/mavuno_reporting.sqlite');wb=Workbook.create()
def sheet(name,headers,rows,width=19,color='#B7791F'):
 s=wb.worksheets.add(name);data=[headers]+[list(r) for r in rows]
 s.get_range_by_indexes(0,0,len(data),len(headers)).values=data
 s.get_range_by_indexes(0,0,1,len(headers)).format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF'},'row_height':29}
 s.get_range_by_indexes(0,0,len(data),len(headers)).format.column_width=width
 s.freeze_panes.freeze_rows(1);s.tab_color=color
 return s
# Preserve previous edition's executive branch summary.
branch=con.execute('''SELECT c.branch, COUNT(DISTINCT c.customer_id), COUNT(DISTINCT t.transaction_id), ROUND(COALESCE(SUM(t.amount),0),2) FROM customers c LEFT JOIN transactions t ON c.customer_id=t.customer_id GROUP BY c.branch ORDER BY c.branch''').fetchall()
service=con.execute('''SELECT c.branch,COUNT(*),SUM(CASE WHEN s.status='Closed' THEN 1 ELSE 0 END),SUM(CASE WHEN s.status='Closed' AND JULIANDAY(s.resolved_date)-JULIANDAY(s.opened_date)<=3 THEN 1 ELSE 0 END) FROM service_requests s JOIN customers c ON c.customer_id=s.customer_id GROUP BY c.branch ORDER BY c.branch''').fetchall()
old=sheet('Executive Dashboard',['BRANCH','CUSTOMERS','TRANSACTIONS','REVENUE (R)','REQUESTS','CLOSED','WITHIN 3-DAY SLA','SLA RATE'],[list(a)+list(b[1:])+[None] for a,b in zip(branch,service)],23,'#17365D')
for i in range(2,len(branch)+2):old.get_range(f'H{i}').formulas=[[f'=IF(E{i}=0,0,G{i}/E{i})']]
old.get_range(f'H2:H{len(branch)+1}').set_number_format('0.0%');old.get_range(f'D2:D{len(branch)+1}').set_number_format('"R" #,##0.00')
old.get_range('A7').values=[['REPORTING NOTES']];old.get_range('A8').values=[['Synthetic data | 3-day calendar SLA | Static branch summary from the ETL output']]
# monthly summary built using separate transaction and service aggregates to avoid fact-to-fact multiplication.
trans=con.execute('''SELECT SUBSTR(t.transaction_date,1,7),c.branch,COUNT(*),ROUND(SUM(t.amount),2) FROM transactions t JOIN customers c ON c.customer_id=t.customer_id GROUP BY 1,2''').fetchall()
serv=con.execute('''SELECT SUBSTR(s.opened_date,1,7),c.branch,COUNT(*),SUM(CASE WHEN s.status='Closed' THEN 1 ELSE 0 END),SUM(CASE WHEN s.status='Closed' AND JULIANDAY(s.resolved_date)-JULIANDAY(s.opened_date)<=3 THEN 1 ELSE 0 END) FROM service_requests s JOIN customers c ON c.customer_id=s.customer_id GROUP BY 1,2''').fetchall()
tm={(m,b):(n,a) for m,b,n,a in trans};sm={(m,b):(n,c,s) for m,b,n,c,s in serv}
keys=sorted(set(tm)|set(sm));monthly=[[m,b,tm.get((m,b),(0,0))[0],tm.get((m,b),(0,0))[1],*sm.get((m,b),(0,0,0))] for m,b in keys]
summary=sheet('Monthly Summary',['Month','Branch','Transactions','Revenue (R)','Requests','Closed','Within SLA'],monthly,20,'#24745C')
summary.get_range(f'D2:D{len(monthly)+1}').set_number_format('"R" #,##0.00')
# Selector-based dashboard. SUMIFS conditions use '*' wildcard for all branches/months by treating source labels as text.
dash=wb.worksheets.add('Interactive Dashboard');dash.tab_color='#17365D'
dash.get_range('A1:H2').format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF'},'row_height':28}
dash.get_range('A1').values=[['MAVUNO | BUSINESS INTELLIGENCE']]
dash.get_range('A2').values=[['INTERACTIVE EXECUTIVE REPORTING']]
dash.get_range('A4').values=[['BRANCH']];dash.get_range('D4').values=[['REPORTING MONTH']]
dash.get_range('B4').values=[['All Branches']];dash.get_range('E4').values=[['All Months']]
dash.get_range('B4').data_validation={'rule':{'type':'list','values':['All Branches','Johannesburg','Cape Town','Durban']}}
months=sorted(set(m for m,b in keys))
dash.get_range('E4').data_validation={'rule':{'type':'list','values':['All Months']+months}}
dash.get_range('A6:B6').values=[['KPI','VALUE']]
dash.get_range('A7:A12').values=[['Total Revenue (R)'],['Transactions'],['Service Requests'],['Closed Requests'],['Within 3-Day SLA'],['SLA Compliance']]
last=len(monthly)+1
br=f'IF($B$4="All Branches","*",$B$4)';mo=f'IF($E$4="All Months","*",$E$4)'
def sum_metric(col):return f'SUMIFS(\'Monthly Summary\'!${col}$2:${col}${last},\'Monthly Summary\'!$B$2:$B${last},{br},\'Monthly Summary\'!$A$2:$A${last},{mo})'
for row,col in [(7,'D'),(8,'C'),(9,'E'),(10,'F'),(11,'G')]:dash.get_range(f'B{row}').formulas=[[f'={sum_metric(col)}']]
dash.get_range('B12').formulas=[['=IF(B9=0,0,B11/B9)']]
dash.get_range('B7').set_number_format('"R" #,##0.00');dash.get_range('B12').set_number_format('0.0%')
dash.get_range('A15').values=[['BRANCH PERFORMANCE']]
dash.get_range('A16:D16').values=[['Branch','Revenue (R)','Transactions','Requests']]
for idx,name in enumerate(['Johannesburg','Cape Town','Durban'],17):
 dash.get_range(f'A{idx}').values=[[name]]
 for col,source in [('B','D'),('C','C'),('D','E')]:
  dash.get_range(f'{col}{idx}').formulas=[[f'=IF(OR($B$4="All Branches",$B$4=A{idx}),SUMIFS(\'Monthly Summary\'!${source}$2:${source}${last},\'Monthly Summary\'!$B$2:$B${last},A{idx},\'Monthly Summary\'!$A$2:$A${last},{mo}),0)']]
dash.get_range('B17:B19').set_number_format('"R" #,##0.00')
dash.get_range('A22').values=[['REFRESH: Run python refresh.py, then reopen this workbook. Select filters above.']]
dash.get_range('A23').values=[['All customer email addresses are fictional samples; no real mailbox ownership is implied.']]
dash.get_range('A1:H24').format.column_width=20
dash.get_range('A:A').format.column_width=31;dash.get_range('B:B').format.column_width=24
dash.get_range('A6:B6').format={'fill':'#24745C','font':{'bold':True,'color':'#FFFFFF'}}
dash.get_range('A16:D16').format={'fill':'#24745C','font':{'bold':True,'color':'#FFFFFF'}}
dash.get_range('B4').format={'fill':'#E7F2F6','font':{'bold':True,'color':'#17365D'}}
dash.get_range('E4').format={'fill':'#E7F2F6','font':{'bold':True,'color':'#17365D'}}
dash.freeze_panes.freeze_rows(2)
customers=con.execute('SELECT * FROM customers ORDER BY customer_id').fetchall();transactions=con.execute('SELECT * FROM transactions ORDER BY transaction_id').fetchall();requests=con.execute('SELECT * FROM service_requests ORDER BY request_id').fetchall()
sheet('Customers',['Customer ID','Customer Name','Branch','Email'],customers,24)
sheet('Transactions',['Transaction ID','Customer ID','Date','Amount (R)','Service'],transactions,23)
sheet('Service Requests',['Request ID','Customer ID','Opened','Resolved','Status','Service'],requests,23)
with (root/'output/load_summary.csv').open() as f:
 rows=list(csv.reader(f));sheet('Data Quality Audit',rows[0],[[v if i==0 else int(v) for i,v in enumerate(row)] for row in rows[1:]],25,'#7357A6')
with (root/'output/exceptions.csv').open() as f:
 rows=list(csv.reader(f));sheet('Rejected Records',rows[0],rows[1:],28,'#7357A6')
raw=[]
for file in sorted((root/'data/incoming').glob('transactions_*.csv')):
 with file.open(newline='') as f:
  rows=list(csv.reader(f));raw.extend(rows if not raw else rows[1:])
sheet('Raw Transactions',raw[0],raw[1:],24,'#7357A6')
# Additional reporting layers (V3/V4/V5/V8).
def sqlsheet(title, headers, query, color='#24745C', width=23):
 return sheet(title,headers,con.execute(query).fetchall(),width,color)
sqlsheet('File Intake History',['File','SHA-256','Dataset','Processed UTC','Raw','Accepted','Rejected'],'SELECT filename,sha256,dataset,processed_at,raw_rows,accepted_rows,rejected_rows FROM file_manifest ORDER BY filename','#7357A6')
sqlsheet('Pipeline Run History',['Run ID','Run UTC','Status','Files Changed','Records Loaded','Message'],'SELECT run_id,run_at,status,files_changed,records_loaded,message FROM pipeline_runs ORDER BY run_id DESC LIMIT 100','#7357A6')
sqlsheet('Customer Dimension',['Customer Key','Customer ID','Customer Name','Branch Key','Email'],'SELECT customer_key,customer_id,customer_name,branch_key,email FROM dim_customer ORDER BY customer_key')
sqlsheet('Branch Dimension',['Branch Key','Branch Name'],'SELECT branch_key,branch_name FROM dim_branch ORDER BY branch_key')
sqlsheet('Date Dimension',['Date Key','Date','Year','Month','Month Label'],'SELECT date_key,calendar_date,year,month,month_label FROM dim_date ORDER BY date_key')
sqlsheet('Transaction Fact',['Transaction ID','Customer Key','Branch Key','Date Key','Amount','Service'],'SELECT transaction_id,customer_key,branch_key,date_key,amount,service FROM fact_transactions ORDER BY transaction_id')
sqlsheet('Service Fact',['Request ID','Customer Key','Branch Key','Opened Key','Resolved Key','Status','Service','Within SLA'],'SELECT request_id,customer_key,branch_key,opened_date_key,resolved_date_key,status,service,within_sla FROM fact_service_requests ORDER BY request_id')
sqlsheet('Alert Rules',['Rule Code','Threshold','Enabled'],'SELECT rule_code,threshold,enabled FROM alert_rules ORDER BY rule_code','#B7791F')
sqlsheet('Management Alerts',['Run UTC','Rule Code','Severity','Observed','Threshold','Message'],'SELECT run_at,rule_code,severity,observed,threshold,message FROM management_alerts ORDER BY run_at DESC','#B7791F')
sqlsheet('Data Quality Exceptions',['Dataset','File','Source Row','Severity','Rule Code','Reason','Raw Record'],'SELECT dataset,source_file,source_row,severity,rule_code,reason,raw_record FROM file_exceptions ORDER BY source_file,source_row','#7357A6',28)
nav=wb.worksheets.add('Navigation');nav.tab_color='#17365D'
nav.get_range('A1:D2').format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF'}}
nav.get_range('A1').values=[['MAVUNO | DATA INTELLIGENCE WORKSPACE']]
nav.get_range('A3:B3').values=[['WORKSPACE','OPEN SHEET']]
nav.get_range('A3:B3').format={'fill':'#24745C','font':{'bold':True,'color':'#FFFFFF'}}
names=['Interactive Dashboard','Executive Dashboard','Monthly Summary','Data Quality Audit','Data Quality Exceptions','File Intake History','Pipeline Run History','Management Alerts','Alert Rules','Customer Dimension','Branch Dimension','Date Dimension','Transaction Fact','Service Fact','Customers','Transactions','Service Requests','Raw Transactions']
for row,name in enumerate(names,4):
 nav.get_range(f'A{row}').values=[[name]]
 nav.get_range(f'B{row}').formulas=[[f'=HYPERLINK("#\'{name}\'!A1","Open")']]
nav.get_range('A:A').format.column_width=34
nav.get_range('B:B').format.column_width=18
nav.freeze_panes.freeze_rows(3)

wb.worksheets.set_active_worksheet('Interactive Dashboard')
SpreadsheetFile.export_xlsx(wb).save(str(root/'NM_Mavuno_Executive_Reporting.xlsx'))
print('Interactive Excel report created; months:',months,'monthly rows:',len(monthly),'customers:',len(customers))
