"""Non-destructive tests for the current prepared demo data."""
import sqlite3,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,str(root/'pipeline.py')],check=True,cwd=root)
con=sqlite3.connect(root/'output/mavuno_reporting.sqlite')
assert con.execute('SELECT files_changed FROM pipeline_runs ORDER BY run_id DESC LIMIT 1').fetchone()[0]==0, 'unchanged files should not reprocess'
for a,b in [('customers','dim_customer'),('transactions','fact_transactions'),('service_requests','fact_service_requests')]:
 assert con.execute('SELECT COUNT(*) FROM '+a).fetchone()[0]==con.execute('SELECT COUNT(*) FROM '+b).fetchone()[0],f'{a} and {b} mismatch'
assert con.execute('PRAGMA foreign_key_check').fetchall()==[], 'foreign key violation'
assert con.execute('SELECT COUNT(*) FROM file_manifest').fetchone()[0]>=5
print('PASS: unchanged-file intake, fact counts and referential integrity')
