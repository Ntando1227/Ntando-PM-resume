import csv,random,datetime,pathlib
r=random.Random(42); root=pathlib.Path(__file__).parent; out=root/'data/incoming'; out.mkdir(parents=True,exist_ok=True)
branches=['JHB',' johannesburg ','Cape Town','CPT','Durban','DBN']; names=['Thabo Mokoena','Lerato Nkosi','Ayesha Patel','Sipho Dlamini','Naledi Maseko','Zanele Khumalo','Mpho Naidoo','Kabelo Sithole']; services=['Installation','Support','Consulting','Maintenance']
with (out/'customers_2026_10.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['customer_id','customer_name','branch','email']);
 for i in range(1,151):w.writerow([f'C{i:04}',f'  {names[i%8]}  ' if i%7==0 else names[i%8],branches[i%6],f"client{i:03d}@{'ntandorocks.com' if i%2 else 'ntandothebest.com'}" if i%19 else ''])
with (out/'transactions_2026_10.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['transaction_id','customer_id','transaction_date','amount','service']);rows=[]
 for i in range(1,501):
  amt=round(r.uniform(150,9000),2);date=datetime.date(2026,10,r.randint(1,28)); row=[f'T{i:05}',f'C{r.randint(1,150):04}',date.strftime('%d/%m/%Y') if i%3 else date.isoformat(),f'R {amt:,.2f}' if i%4 else str(amt),services[i%4]]
  if i%83==0:row[3]='invalid'
  if i%101==0:row[1]='C9999'
  rows.append(row);w.writerow(row)
 for i in [12,44,97,201,333]:w.writerow(rows[i])
with (out/'service_requests_2026_10.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['request_id','customer_id','opened_date','resolved_date','status','service']);
 for i in range(1,351):
  d=datetime.date(2026,10,r.randint(1,25)); closed=i%7!=0; resolved=d+datetime.timedelta(days=r.randint(0,8)) if closed else None
  w.writerow([f'S{i:05}',f'C{r.randint(1,150):04}',d.isoformat(),resolved.isoformat() if resolved else '', ' CLOSED ' if closed and i%4==0 else ('Closed' if closed else 'open'),services[i%4]])
print('Created synthetic CSV inputs')
