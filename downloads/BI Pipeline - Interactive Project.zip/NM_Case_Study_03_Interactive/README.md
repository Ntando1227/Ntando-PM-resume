# NM Case Study 03 — Automated Business Intelligence Pipeline (Interactive Edition)

Fictional Mavuno Business Solutions dataset. Email addresses use **illustrative, unverified** `@ntandorocks.com` and `@ntandothebest.com` domains; they are sample strings, not provisioned mailboxes. Do not send messages to them.

## Refresh the complete system

1. Install Python and the `artifact_tool` package in an environment that supports it.
2. Add monthly `customers_YYYY_MM.csv`, `transactions_YYYY_MM.csv`, and `service_requests_YYYY_MM.csv` files to `data/incoming/`, preserving the supplied column names.
3. Run `python refresh.py` from this folder. This runs the Python ETL, rebuilds the SQLite reporting tables and exports the Excel report.
4. Open `NM_Mavuno_Executive_Reporting.xlsx`, select a branch and month on **Interactive Dashboard**.

The pipeline reads every matching CSV, validates rows, deduplicates by source IDs, and produces `output/exceptions.csv`, `output/load_summary.csv` and `output/mavuno_reporting.sqlite`. Repeat runs replace the reporting tables atomically and append to the audit history; the same source files do not accumulate duplicate reporting records. The refresh is **command-triggered**, not an automatic background file watcher or live Excel connection.

## Workbook guide

- **Interactive Dashboard**: branch/month dropdowns; formula-based revenue, transaction and service metrics.
- **Monthly Summary**: transaction and service metrics by month and branch, feeding the dashboard.
- **Executive Dashboard**: retained static branch snapshot from the previous edition.
- **Customers / Transactions / Service Requests**: cleaned data extracted from SQLite.
- **Data Quality Audit / Rejected Records / Raw Transactions**: validation evidence.

### Important data notes

The generated customer email addresses are fictional examples. Existing blank emails are deliberately preserved as data-quality examples. The dashboard's customer count is a count of distinct customer records by branch across the dataset; it does not change by selected month. The 3-day service SLA is based on calendar days. Monthly report figures depend on the incoming files. The Excel workbook is rebuilt by `refresh.py`, so any manual changes to that generated workbook will be overwritten.
