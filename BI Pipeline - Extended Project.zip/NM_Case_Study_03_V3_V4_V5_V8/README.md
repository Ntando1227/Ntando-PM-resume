# NM Case Study 03 — Data Integration & BI (V3, V4, V5, V8)

**Fictional Mavuno Business Solutions.** All customer information is synthetic. The sample domains `ntandorocks.com` and `ntandothebest.com` are illustrative and are not verified or provisioned mailboxes. Do not send messages to them.

## Run

From this folder, run `python refresh.py`. Python's standard library handles the ETL, SQLite and alert generation. The Excel snapshot generator requires `artifact_tool`. If you only need the database, run `python pipeline.py` then `python alerts.py`.

## What each iteration does

- **V3 — Incremental file intake:** Place correctly named `customers_YYYY_MM.csv`, `transactions_YYYY_MM.csv`, or `service_requests_YYYY_MM.csv` files in `data/incoming`. SHA-256 checksums in `file_manifest` identify new/changed files. Unchanged files are not reparsed. Changed files replace their staged rows; reporting tables are **reconciled atomically from staging** to handle changed customer references safely. This is not an append-only fact loader. The `pipeline_runs` table logs runs and errors. Do not rename previously loaded source files without understanding the staging history.
- **V4 — Data quality:** Required-column checks, normalised names and branches, allowed sample email domains, date/amount validation, duplicate IDs, referential integrity and `output/exceptions.csv`. Rejected source rows are retained in `file_exceptions`. `output/load_summary.csv` includes post-reconciliation rejected counts.
- **V5 — Dimensional warehouse:** SQLite tables `dim_branch`, `dim_customer`, `dim_date`, `fact_transactions`, and `fact_service_requests` alongside the existing operational tables. Fact tables reference dimension surrogate keys. Dimension keys are rebuilt during reconciliation and **are not persistent historical SCD keys**; this is a portfolio prototype, not Type-2 change tracking.
- **V8 — Management alerts:** Editable thresholds in SQLite `alert_rules`; `alerts.py` checks file rejection rate, open requests older than three calendar days, and revenue declines across the latest two transaction months. Outputs `management_alerts.csv` and `management_summary.md`. **No external notifications are sent.** For scheduled refresh, configure your computer's Task Scheduler or cron; no unattended scheduler is running by default.

## Excel reporting

The existing Interactive Dashboard, Executive Dashboard, Monthly Summary and source worksheets remain. New worksheets show file intake, pipeline runs, data quality exceptions, warehouse dimensions/facts, alert rules and management alerts. A Navigation worksheet provides hyperlinks to key areas. `refresh.py` regenerates the workbook, so changes made directly to the generated Excel file will be overwritten.

## Suggested Windows Task Scheduler configuration

Create a Basic Task (daily at your chosen time). Program: the absolute path to `python.exe` in your environment. Arguments: the absolute path to `refresh.py`. Start in: this project folder. The computer must be on and the Python environment must have `artifact_tool` installed. Check `output/pipeline_runs.csv` and `output/management_summary.md` after execution. No emails are sent automatically.

## Validation

Run `python tests/test_pipeline.py` to confirm unchanged-file idempotence and warehouse row consistency. Source schema is defined in `pipeline.py` (`SCHEMAS`). Rejection thresholds can be changed with SQL such as `UPDATE alert_rules SET threshold=10 WHERE rule_code='HIGH_REJECTION_RATE';`.

## Limitations

This is a local SQLite and Excel prototype. It does not yet implement a cloud upload trigger, Power BI service refresh, Type-2 customer history, production authentication, or email delivery. Avoid putting real customer information into this demo without implementing appropriate privacy and security controls.
