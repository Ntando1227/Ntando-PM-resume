# NM Case Study 03 — Automated Business Data Integration & Reporting

A fictional, runnable business intelligence case study demonstrating raw data ingestion, standardisation, duplicate detection, referential checks, exception management, SQLite data modelling and Excel reporting.

## Quick start

Requires Python 3.10+; no third-party packages are needed to run the ETL.

```bash
python build_demo.py   # optional: regenerate the synthetic raw data
python pipeline.py     # refresh the SQLite database and audit files
```

Open `NM_Mavuno_Executive_Reporting.xlsx` for the illustrative reporting dashboard. **The Excel workbook is a snapshot of a completed pipeline run**, not a live SQL-connected or Power BI report. To refresh the Excel dashboard after new inputs, run `pipeline.py` and rebuild the workbook using the supplied `build_report.py` (requires `artifact_tool` in the reporting environment).

## Files
- `data/incoming/`: fictional, intentionally inconsistent source files.
- `pipeline.py`: idempotent ETL; validates keys, parses dates and amounts, normalises branches and statuses.
- `output/mavuno_reporting.sqlite`: relational data model with customers, transactions, service requests, and load audit.
- `output/exceptions.csv`: rejected rows and reasons.
- `output/load_summary.csv`: raw, accepted and rejected counts.
- `sql/reporting_queries.sql`: reusable SQL business reporting queries.
- `NM_Mavuno_Executive_Reporting.xlsx`: Excel reporting snapshot.

## Business rules and caveats
- Customer IDs, transaction IDs and service request IDs are permanent keys.
- Unknown customer references are rejected rather than silently joined.
- Duplicate transaction IDs are rejected; the first valid occurrence wins.
- Resolution within 3 calendar days is the illustrative SLA.
- Input files matching the named patterns are processed together; archive old files before adding overlapping monthly extracts to avoid cross-file ID collisions.
- ETL replaces current customer, transaction and service tables each run, and retains historical load audit rows. It is a full-refresh prototype, not incremental ingestion.
- All people, companies and figures are synthetic.
