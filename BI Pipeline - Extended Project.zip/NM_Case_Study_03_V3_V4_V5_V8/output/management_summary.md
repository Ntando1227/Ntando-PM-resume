# Mavuno Management Refresh Summary

Run: 2026-11-10T20:15:19.560516+00:00

Raw rows: 1225; accepted file rows: 1213; rejection rate: 0.98%

Open service requests beyond 3 days: 64

## Alerts

- **OVERDUE_OPEN_REQUESTS**: 64 open requests older than 3 days

Generated locally; no emails sent.
