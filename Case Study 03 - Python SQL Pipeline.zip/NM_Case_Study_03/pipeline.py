"""Repeatable CSV -> SQLite ETL with exception logging and load audits. Python standard library only."""
import csv,sqlite3,pathlib,re,datetime,sys
ROOT=pathlib.Path(__file__).parent; INPUT=ROOT/'data/incoming'; OUTPUT=ROOT/'output'; OUTPUT.mkdir(exist_ok=True)
DB=OUTPUT/'mavuno_reporting.sqlite'; issues=[];counts={}
def read(pattern):
 files=sorted(INPUT.glob(pattern)); records=[]
 for file in files:
  with file.open(newline='',encoding='utf-8-sig') as f:
   for n,row in enumerate(csv.DictReader(f),2):records.append((file.name,n,row))
 return records
def reject(kind,file,line,reason,row):issues.append([kind,file,line,reason,str(row)])
def date(s):
 for fmt in ('%Y-%m-%d','%d/%m/%Y'):
  try:return datetime.datetime.strptime(s.strip(),fmt).date().isoformat()
  except ValueError:pass
 raise ValueError('invalid date')
def branch(s):
 key=re.sub(r'\s+',' ',s.strip().lower()); mapping={'jhb':'Johannesburg','johannesburg':'Johannesburg','cpt':'Cape Town','cape town':'Cape Town','dbn':'Durban','durban':'Durban'}
 if key not in mapping:raise ValueError('unknown branch')
 return mapping[key]
def export(name,header,rows):
 with (OUTPUT/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(header);w.writerows(rows)
con=sqlite3.connect(DB);con.execute('PRAGMA foreign_keys=ON');con.executescript('''CREATE TABLE IF NOT EXISTS customers(customer_id TEXT PRIMARY KEY, customer_name TEXT NOT NULL, branch TEXT NOT NULL,email TEXT); CREATE TABLE IF NOT EXISTS transactions(transaction_id TEXT PRIMARY KEY, customer_id TEXT NOT NULL REFERENCES customers(customer_id), transaction_date TEXT NOT NULL,amount REAL NOT NULL CHECK(amount>=0),service TEXT NOT NULL); CREATE TABLE IF NOT EXISTS service_requests(request_id TEXT PRIMARY KEY,customer_id TEXT NOT NULL REFERENCES customers(customer_id),opened_date TEXT NOT NULL,resolved_date TEXT,status TEXT NOT NULL,service TEXT NOT NULL); CREATE TABLE IF NOT EXISTS load_audit(run_at TEXT,source TEXT,raw_rows INTEGER,accepted_rows INTEGER,rejected_rows INTEGER);''')
# Replace facts atomically so repeated runs are idempotent; retain load history.
try:
 con.execute('BEGIN');con.execute('DELETE FROM transactions');con.execute('DELETE FROM service_requests');con.execute('DELETE FROM customers')
 customers=[];seen=set();raw=read('customers_*.csv')
 for file,line,row in raw:
  try:
   cid=row['customer_id'].strip().upper();name=' '.join(row['customer_name'].split());b=branch(row['branch']);email=row['email'].strip().lower()
   if not cid or not name or cid in seen:raise ValueError('missing or duplicate customer')
   seen.add(cid);customers.append((cid,name,b,email))
  except Exception as e:reject('customers',file,line,str(e),row)
 con.executemany('INSERT INTO customers VALUES(?,?,?,?)',customers);counts['customers']=(len(raw),len(customers))
 transactions=[];seen=set();raw=read('transactions_*.csv')
 for file,line,row in raw:
  try:
   tid=row['transaction_id'].strip().upper();cid=row['customer_id'].strip().upper();d=date(row['transaction_date']);a=float(re.sub(r'[R,\s]','',row['amount']));service=row['service'].strip()
   if tid in seen:raise ValueError('duplicate transaction ID')
   if cid not in {c[0] for c in customers}:raise ValueError('unknown customer')
   if a<0:raise ValueError('negative amount')
   seen.add(tid);transactions.append((tid,cid,d,a,service))
  except Exception as e:reject('transactions',file,line,str(e),row)
 con.executemany('INSERT INTO transactions VALUES(?,?,?,?,?)',transactions);counts['transactions']=(len(raw),len(transactions))
 requests=[];seen=set();raw=read('service_requests_*.csv')
 for file,line,row in raw:
  try:
   rid=row['request_id'].strip().upper();cid=row['customer_id'].strip().upper();opened=date(row['opened_date']);resolved=date(row['resolved_date']) if row['resolved_date'].strip() else None;status=row['status'].strip().title()
   if rid in seen or cid not in {c[0] for c in customers}:raise ValueError('duplicate request or unknown customer')
   if resolved and resolved<opened:raise ValueError('resolution before opening')
   if status not in ('Open','Closed'):raise ValueError('invalid status')
   seen.add(rid);requests.append((rid,cid,opened,resolved,status,row['service'].strip()))
  except Exception as e:reject('service_requests',file,line,str(e),row)
 con.executemany('INSERT INTO service_requests VALUES(?,?,?,?,?,?)',requests);counts['service_requests']=(len(raw),len(requests))
 now=datetime.datetime.now(datetime.timezone.utc).isoformat()
 for name,(total,accepted) in counts.items():con.execute('INSERT INTO load_audit VALUES(?,?,?,?,?)',(now,name,total,accepted,total-accepted))
 con.commit()
except Exception:
 con.rollback();raise
finally:con.close()
export('exceptions.csv',['dataset','file','source_row','reason','raw_record'],issues)
export('load_summary.csv',['dataset','raw_rows','accepted_rows','rejected_rows'],[[name,total,accepted,total-accepted] for name,(total,accepted) in counts.items()])
print('ETL complete:',counts,'exceptions:',len(issues),'database:',DB)
