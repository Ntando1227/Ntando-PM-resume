from artifact_tool import Workbook,SpreadsheetFile
import sqlite3,csv,pathlib
root=pathlib.Path(__file__).parent;db=sqlite3.connect(root/'output/mavuno_reporting.sqlite');wb=Workbook.create()
def sheet(name,headers,rows,width=19):
 s=wb.worksheets.add(name);data=[headers]+[list(r) for r in rows];s.get_range_by_indexes(0,0,len(data),len(headers)).values=data
 h=s.get_range_by_indexes(0,0,1,len(headers));h.format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF'},'row_height':30};s.get_range_by_indexes(0,0,len(data),len(headers)).format.column_width=width;s.freeze_panes.freeze_rows(1);s.tab_color='#24745C';return s
branch=db.execute('''SELECT c.branch, COUNT(DISTINCT c.customer_id), COUNT(DISTINCT t.transaction_id), ROUND(COALESCE(SUM(t.amount),0),2) FROM customers c LEFT JOIN transactions t ON c.customer_id=t.customer_id GROUP BY c.branch ORDER BY c.branch''').fetchall()
service=db.execute('''SELECT c.branch,COUNT(*),SUM(CASE WHEN s.status='Closed' THEN 1 ELSE 0 END),SUM(CASE WHEN s.status='Closed' AND JULIANDAY(s.resolved_date)-JULIANDAY(s.opened_date)<=3 THEN 1 ELSE 0 END) FROM service_requests s JOIN customers c ON c.customer_id=s.customer_id GROUP BY c.branch ORDER BY c.branch''').fetchall()
summary=sheet('Executive Dashboard',['BRANCH','CUSTOMERS','TRANSACTIONS','REVENUE (R)','REQUESTS','CLOSED','WITHIN 3-DAY SLA','SLA RATE'],[list(a)+list(b[1:])+[None] for a,b in zip(branch,service)],23)
for i in range(2,5):summary.get_range(f'H{i}').formulas=[[f'=IF(E{i}=0,0,G{i}/E{i})']]
summary.get_range('H2:H4').set_number_format('0.0%');summary.get_range('D2:D4').set_number_format('"R" #,##0.00');summary.get_range('A7').values=[['REPORTING NOTES']];summary.get_range('A8').values=[['Synthetic October 2026 data | 3-day calendar SLA | Static snapshot of Python ETL output']];summary.get_range('A10').values=[['Raw → Python ETL → SQLite → Reporting workbook']];summary.tab_color='#17365D'
customers=db.execute('SELECT * FROM customers ORDER BY customer_id').fetchall();transactions=db.execute('SELECT * FROM transactions ORDER BY transaction_id').fetchall();requests=db.execute('SELECT * FROM service_requests ORDER BY request_id').fetchall()
sheet('Customers',['Customer ID','Customer Name','Branch','Email'],customers,23).tab_color='#B7791F'
sheet('Transactions',['Transaction ID','Customer ID','Date','Amount (R)','Service'],transactions,23).tab_color='#B7791F'
sheet('Service Requests',['Request ID','Customer ID','Opened','Resolved','Status','Service'],requests,23).tab_color='#B7791F'
with (root/'output/load_summary.csv').open() as f:rows=list(csv.reader(f));sheet('Data Quality Audit',rows[0],[[v if i==0 else int(v) for i,v in enumerate(row)] for row in rows[1:]],25)
with (root/'output/exceptions.csv').open() as f:rows=list(csv.reader(f));sheet('Rejected Records',rows[0],rows[1:],28)
raw=[]
with (root/'data/incoming/transactions_2026_10.csv').open() as f:raw=list(csv.reader(f))
sheet('Raw Transactions',raw[0],raw[1:],24).tab_color='#7357A6'
wb.worksheets.set_active_worksheet('Executive Dashboard');SpreadsheetFile.export_xlsx(wb).save(str(root/'NM_Mavuno_Executive_Reporting.xlsx'))
print('Excel report created; branch totals:',branch)
