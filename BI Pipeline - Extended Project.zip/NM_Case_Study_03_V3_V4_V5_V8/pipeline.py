"""Incremental, auditable CSV -> SQLite ETL. Standard library only."""
import csv, sqlite3, pathlib, re, datetime, hashlib, json, os
ROOT=pathlib.Path(__file__).parent; INPUT=ROOT/'data/incoming'; OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)
DB=OUT/'mavuno_reporting.sqlite'; NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
SCHEMAS={'customers':['customer_id','customer_name','branch','email'],'transactions':['transaction_id','customer_id','transaction_date','amount','service'],'service_requests':['request_id','customer_id','opened_date','resolved_date','status','service']}
ALLOWED_DOMAINS={'ntandorocks.com','ntandothebest.com'}
def export(name,headers,rows):
 with (OUT/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(headers);w.writerows(rows)
def clean_date(v):
 for fmt in ('%Y-%m-%d','%d/%m/%Y'):
  try:return datetime.datetime.strptime(v.strip(),fmt).date().isoformat()
  except ValueError:pass
 raise ValueError('invalid date')
def branch(v):
 mapping={'jhb':'Johannesburg','johannesburg':'Johannesburg','cpt':'Cape Town','cape town':'Cape Town','dbn':'Durban','durban':'Durban'}
 k=' '.join(v.lower().split())
 if k not in mapping:raise ValueError('unknown branch')
 return mapping[k]
def validate(kind,r):
 if kind=='customers':
  cid=r['customer_id'].strip().upper(); name=' '.join(r['customer_name'].split()); email=r['email'].strip().lower()
  if not cid or not name:raise ValueError('missing customer ID or name')
  if email and not re.fullmatch(r'[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}',email):raise ValueError('invalid email format')
  if email and email.rsplit('@',1)[1] not in ALLOWED_DOMAINS:raise ValueError('email domain not in approved sample list')
  return (cid,name,branch(r['branch']),email)
 if kind=='transactions':
  tid=r['transaction_id'].strip().upper();cid=r['customer_id'].strip().upper();d=clean_date(r['transaction_date']); a=float(re.sub(r'[R,\s]','',r['amount'])); service=r['service'].strip()
  if not tid or not cid or not service or not 0<=a<=10000000:raise ValueError('missing ID/service or out-of-range amount')
  return (tid,cid,d,a,service)
 rid=r['request_id'].strip().upper();cid=r['customer_id'].strip().upper();opened=clean_date(r['opened_date']);resolved=clean_date(r['resolved_date']) if r['resolved_date'].strip() else None;status=r['status'].strip().title();service=r['service'].strip()
 if not rid or not cid or not service or status not in ('Open','Closed'):raise ValueError('missing ID/service or invalid status')
 if resolved and resolved<opened:raise ValueError('resolution before opening')
 if status=='Closed' and not resolved:raise ValueError('closed request missing resolution date')
 return (rid,cid,opened,resolved,status,service)
con=sqlite3.connect(DB);con.execute('PRAGMA foreign_keys=ON')
con.executescript('''
CREATE TABLE IF NOT EXISTS customers(customer_id TEXT PRIMARY KEY,customer_name TEXT NOT NULL,branch TEXT NOT NULL,email TEXT);
CREATE TABLE IF NOT EXISTS transactions(transaction_id TEXT PRIMARY KEY,customer_id TEXT NOT NULL REFERENCES customers(customer_id),transaction_date TEXT NOT NULL,amount REAL NOT NULL CHECK(amount>=0),service TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS service_requests(request_id TEXT PRIMARY KEY,customer_id TEXT NOT NULL REFERENCES customers(customer_id),opened_date TEXT NOT NULL,resolved_date TEXT,status TEXT NOT NULL,service TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS load_audit(run_at TEXT,source TEXT,raw_rows INTEGER,accepted_rows INTEGER,rejected_rows INTEGER);
CREATE TABLE IF NOT EXISTS file_manifest(filename TEXT PRIMARY KEY,sha256 TEXT NOT NULL,dataset TEXT NOT NULL,processed_at TEXT NOT NULL,raw_rows INTEGER,accepted_rows INTEGER,rejected_rows INTEGER);
CREATE TABLE IF NOT EXISTS staged_rows(dataset TEXT NOT NULL,source_file TEXT NOT NULL,source_row INTEGER NOT NULL,business_id TEXT NOT NULL,payload TEXT NOT NULL,PRIMARY KEY(dataset,source_file,source_row));
CREATE TABLE IF NOT EXISTS file_exceptions(dataset TEXT,source_file TEXT,source_row INTEGER,severity TEXT,rule_code TEXT,reason TEXT,raw_record TEXT);
CREATE TABLE IF NOT EXISTS pipeline_runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT,run_at TEXT,status TEXT,files_changed INTEGER,records_loaded INTEGER,message TEXT);
CREATE TABLE IF NOT EXISTS dim_branch(branch_key INTEGER PRIMARY KEY,branch_name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS dim_date(date_key INTEGER PRIMARY KEY,calendar_date TEXT UNIQUE NOT NULL,year INTEGER,month INTEGER,month_label TEXT);
CREATE TABLE IF NOT EXISTS dim_customer(customer_key INTEGER PRIMARY KEY,customer_id TEXT UNIQUE NOT NULL,customer_name TEXT,branch_key INTEGER REFERENCES dim_branch(branch_key),email TEXT);
CREATE TABLE IF NOT EXISTS fact_transactions(transaction_id TEXT PRIMARY KEY,customer_key INTEGER REFERENCES dim_customer(customer_key),branch_key INTEGER REFERENCES dim_branch(branch_key),date_key INTEGER REFERENCES dim_date(date_key),amount REAL,service TEXT);
CREATE TABLE IF NOT EXISTS fact_service_requests(request_id TEXT PRIMARY KEY,customer_key INTEGER REFERENCES dim_customer(customer_key),branch_key INTEGER REFERENCES dim_branch(branch_key),opened_date_key INTEGER REFERENCES dim_date(date_key),resolved_date_key INTEGER REFERENCES dim_date(date_key),status TEXT,service TEXT,within_sla INTEGER);
CREATE TABLE IF NOT EXISTS alert_rules(rule_code TEXT PRIMARY KEY,threshold REAL NOT NULL,enabled INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS management_alerts(run_at TEXT,rule_code TEXT,severity TEXT,observed REAL,threshold REAL,message TEXT);
''')
for code,threshold in [('HIGH_REJECTION_RATE',5),('OVERDUE_OPEN_REQUESTS',0),('REVENUE_DECLINE_PCT',15)]:con.execute('INSERT OR IGNORE INTO alert_rules VALUES(?,?,1)',(code,threshold))
con.commit()
files=[]
for kind in SCHEMAS:
 for p in sorted(INPUT.glob(kind+'_*.csv')):
  digest=hashlib.sha256(p.read_bytes()).hexdigest();prior=con.execute('SELECT sha256 FROM file_manifest WHERE filename=?',(p.name,)).fetchone()
  if prior is None or prior[0]!=digest:files.append((kind,p,digest))
changed=[]
try:
 con.execute('BEGIN')
 for kind,p,digest in files:
  with p.open(newline='',encoding='utf-8-sig') as f:
   reader=csv.DictReader(f)
   if reader.fieldnames is None or set(SCHEMAS[kind])-set(reader.fieldnames):raise ValueError(f'{p.name}: missing required columns {set(SCHEMAS[kind])-set(reader.fieldnames or [])}')
   records=list(reader)
  con.execute('DELETE FROM staged_rows WHERE source_file=?',(p.name,));con.execute('DELETE FROM file_exceptions WHERE source_file=?',(p.name,))
  accepted=0;seen=set()
  for n,row in enumerate(records,2):
   try:
    values=validate(kind,row);id_=values[0]
    if id_ in seen:raise ValueError('duplicate business ID within file')
    seen.add(id_)
    con.execute('INSERT INTO staged_rows VALUES(?,?,?,?,?)',(kind,p.name,n,id_,json.dumps(values)))
    accepted+=1
   except (ValueError,KeyError,TypeError) as e:
    reason=str(e);code='DUPLICATE_ID' if 'duplicate' in reason else 'INVALID_RECORD'
    con.execute('INSERT INTO file_exceptions VALUES(?,?,?,?,?,?,?)',(kind,p.name,n,'High',code,reason,json.dumps(row)))
  con.execute('INSERT OR REPLACE INTO file_manifest VALUES(?,?,?,?,?,?,?)',(p.name,digest,kind,NOW,len(records),accepted,len(records)-accepted))
  changed.append((kind,p.name,len(records),accepted))
 # Reconcile staging deterministically; changed files only parsed, full reporting tables rebuilt atomically.
 # Last file in sorted name order wins for matching business IDs (e.g. later monthly customer updates).
 winners={}
 for kind,file,row,id_,payload in con.execute('SELECT dataset,source_file,source_row,business_id,payload FROM staged_rows ORDER BY source_file,source_row'):
  winners[(kind,id_)]=(file,row,json.loads(payload))
 customers=[v[2] for (kind,_),v in winners.items() if kind=='customers']; customer_ids={r[0] for r in customers}
 con.execute('DELETE FROM fact_transactions');con.execute('DELETE FROM fact_service_requests');con.execute('DELETE FROM dim_customer');con.execute('DELETE FROM dim_date');con.execute('DELETE FROM dim_branch')
 con.execute('DELETE FROM transactions');con.execute('DELETE FROM service_requests');con.execute('DELETE FROM customers')
 con.executemany('INSERT INTO customers VALUES(?,?,?,?)',customers)
 valid={'customers':customers,'transactions':[],'service_requests':[]};cross=[]
 for kind in ('transactions','service_requests'):
  for (k,id_), (file,row,values) in winners.items():
   if k!=kind:continue
   if values[1] not in customer_ids:
    cross.append((kind,file,row,'High','UNKNOWN_CUSTOMER','customer ID not in master',json.dumps(values)));continue
   valid[kind].append(values)
 con.executemany('INSERT INTO transactions VALUES(?,?,?,?,?)',valid['transactions'])
 con.executemany('INSERT INTO service_requests VALUES(?,?,?,?,?,?)',valid['service_requests'])
 for branch_key,bname in enumerate(('Johannesburg','Cape Town','Durban'),1):con.execute('INSERT INTO dim_branch VALUES(?,?)',(branch_key,bname))
 for d in sorted({r[2] for r in valid['transactions']}|{r[2] for r in valid['service_requests']}|{r[3] for r in valid['service_requests'] if r[3]}):
  dt=datetime.date.fromisoformat(d);con.execute('INSERT INTO dim_date VALUES(?,?,?,?,?)',(int(d.replace('-','')),d,dt.year,dt.month,d[:7]))
 for idx,(cid,name,bname,email) in enumerate(sorted(customers),1):
  bk=con.execute('SELECT branch_key FROM dim_branch WHERE branch_name=?',(bname,)).fetchone()[0]
  con.execute('INSERT INTO dim_customer VALUES(?,?,?,?,?)',(idx,cid,name,bk,email))
 con.execute('''INSERT INTO fact_transactions SELECT t.transaction_id,d.customer_key,d.branch_key,CAST(REPLACE(t.transaction_date,'-','') AS INTEGER),t.amount,t.service FROM transactions t JOIN dim_customer d ON t.customer_id=d.customer_id''')
 con.execute('''INSERT INTO fact_service_requests SELECT s.request_id,d.customer_key,d.branch_key,CAST(REPLACE(s.opened_date,'-','') AS INTEGER),CASE WHEN s.resolved_date IS NOT NULL THEN CAST(REPLACE(s.resolved_date,'-','') AS INTEGER) END,s.status,s.service,CASE WHEN s.status='Closed' AND julianday(s.resolved_date)-julianday(s.opened_date)<=3 THEN 1 ELSE 0 END FROM service_requests s JOIN dim_customer d ON s.customer_id=d.customer_id''')
 for kind,file,raw,accepted in changed:con.execute('INSERT INTO load_audit VALUES(?,?,?,?,?)',(NOW,kind,raw,accepted,raw-accepted))
 con.execute('INSERT INTO pipeline_runs(run_at,status,files_changed,records_loaded,message) VALUES(?,?,?,?,?)',(NOW,'SUCCESS',len(files),sum(map(len,valid.values())),'Incremental intake; atomic reporting reconciliation'))
 con.commit()
except Exception as e:
 con.rollback();con.execute('INSERT INTO pipeline_runs(run_at,status,files_changed,records_loaded,message) VALUES(?,?,?,?,?)',(NOW,'FAILED',len(files),0,str(e)));con.commit();con.close();raise
# Build full exception output without duplicating rows on repeat runs.
exceptions=con.execute('SELECT dataset,source_file,source_row,severity,rule_code,reason,raw_record FROM file_exceptions ORDER BY source_file,source_row').fetchall()+cross
export('exceptions.csv',['dataset','file','source_row','severity','rule_code','reason','raw_record'],exceptions)
summary=[]
for kind in SCHEMAS:
 raw=con.execute('SELECT COALESCE(SUM(raw_rows),0) FROM file_manifest WHERE dataset=?',(kind,)).fetchone()[0]
 accepted=len(valid[kind]);summary.append((kind,raw,accepted,raw-accepted))
export('load_summary.csv',['dataset','raw_rows','accepted_rows','rejected_rows'],summary)
export('file_manifest.csv',['filename','sha256','dataset','processed_at','raw_rows','accepted_rows','rejected_rows'],con.execute('SELECT * FROM file_manifest ORDER BY filename').fetchall())
export('pipeline_runs.csv',['run_id','run_at','status','files_changed','records_loaded','message'],con.execute('SELECT * FROM pipeline_runs ORDER BY run_id DESC LIMIT 100').fetchall())
export('dim_customer.csv',['customer_key','customer_id','customer_name','branch_key','email'],con.execute('SELECT * FROM dim_customer').fetchall())
export('fact_transactions.csv',['transaction_id','customer_key','branch_key','date_key','amount','service'],con.execute('SELECT * FROM fact_transactions').fetchall())
print('ETL OK | changed files:',len(files),'| loaded:',{k:len(v) for k,v in valid.items()},'| exceptions:',len(exceptions))
con.close()
