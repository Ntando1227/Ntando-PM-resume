-- Branch performance with service request resolution and revenue
SELECT c.branch, COUNT(DISTINCT c.customer_id) AS customers,
       COUNT(DISTINCT t.transaction_id) AS transactions,
       ROUND(COALESCE(SUM(t.amount),0),2) AS revenue
FROM customers c LEFT JOIN transactions t ON t.customer_id=c.customer_id
GROUP BY c.branch ORDER BY revenue DESC;

-- Monthly revenue trends
SELECT SUBSTR(transaction_date,1,7) AS month, ROUND(SUM(amount),2) AS revenue,
       COUNT(*) AS transactions
FROM transactions GROUP BY month ORDER BY month;

-- Service performance, based on service-level target of 3 calendar days
SELECT c.branch, COUNT(*) AS requests,
       SUM(CASE WHEN s.status='Closed' THEN 1 ELSE 0 END) AS closed_requests,
       SUM(CASE WHEN s.status='Closed' AND JULIANDAY(s.resolved_date)-JULIANDAY(s.opened_date)<=3 THEN 1 ELSE 0 END) AS within_sla
FROM service_requests s JOIN customers c ON c.customer_id=s.customer_id
GROUP BY c.branch;
