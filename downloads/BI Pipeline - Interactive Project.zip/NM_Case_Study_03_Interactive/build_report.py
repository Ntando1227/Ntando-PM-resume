"""Generate a filterable Excel report from the SQLite reporting database (artifact_tool)."""
from artifact_tool import Workbook,SpreadsheetFile
import sqlite3,csv,pathlib
root=pathlib.Path(__file__).parent;con=sqlite3.connect(root/'output/mavuno_reporting.sqlite');wb=Workbook.create()
def sheet(name,headers,rows,width=19,color='#B7791F'):
 s=wb.worksheets.add(name);data=[headers]+[list(r) for r in rows]
 s.get_range_by_indexes(0,0,len(data),len(headers)).values=data
 s.get_range_by_indexes(0,0,1,len(headers)).format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF'},'row_height':29}
 s.get_range_by_indexes(0,0,len(data),len(headers)).format.column_width=width
 s.freeze_panes.freeze_rows(1);s.tab_color=color
 return s
# Preserve previous edition's executive branch summary.
branch=con.execute('''SELECT c.branch, COUNT(DISTINCT c.customer_id), COUNT(DISTINCT t.transaction_id), ROUND(COALESCE(SUM(t.amount),0),2) FROM customers c LEFT JOIN transactions t ON c.customer_id=t.customer_id GROUP BY c.branch ORDER BY c.branch''').fetchall()
service=con.execute('''SELECT c.branch,COUNT(*),SUM(CASE WHEN s.status='Closed' THEN 1 ELSE 0 END),SUM(CASE WHEN s.status='Closed' AND JULIANDAY(s.resolved_date)-JULIANDAY(s.opened_date)<=3 THEN 1 ELSE 0 END) FROM service_requests s JOIN customers c ON c.customer_id=s.customer_id GROUP BY c.branch ORDER BY c.branch''').fetchall()
old=sheet('Executive Dashboard',['BRANCH','CUSTOMERS','TRANSACTIONS','REVENUE (R)','REQUESTS','CLOSED','WITHIN 3-DAY SLA','SLA RATE'],[list(a)+list(b[1:])+[None] for a,b in zip(branch,service)],23,'#17365D')
for i in range(2,len(branch)+2):old.get_range(f'H{i}').formulas=[[f'=IF(E{i}=0,0,G{i}/E{i})']]
old.get_range(f'H2:H{len(branch)+1}').set_number_format('0.0%');old.get_range(f'D2:D{len(branch)+1}').set_number_format('"R" #,##0.00')
old.get_range('A7').values=[['REPORTING NOTES']];old.get_range('A8').values=[['Synthetic data | 3-day calendar SLA | Static branch summary from the ETL output']]
# monthly summary built using separate transaction and service aggregates to avoid fact-to-fact multiplication.
trans=con.execute('''SELECT SUBSTR(t.transaction_date,1,7),c.branch,COUNT(*),ROUND(SUM(t.amount),2) FROM transactions t JOIN customers c ON c.customer_id=t.customer_id GROUP BY 1,2''').fetchall()
serv=con.execute('''SELECT SUBSTR(s.opened_date,1,7),c.branch,COUNT(*),SUM(CASE WHEN s.status='Closed' THEN 1 ELSE 0 END),SUM(CASE WHEN s.status='Closed' AND JULIANDAY(s.resolved_date)-JULIANDAY(s.opened_date)<=3 THEN 1 ELSE 0 END) FROM service_requests s JOIN customers c ON c.customer_id=s.customer_id GROUP BY 1,2''').fetchall()
tm={(m,b):(n,a) for m,b,n,a in trans};sm={(m,b):(n,c,s) for m,b,n,c,s in serv}
keys=sorted(set(tm)|set(sm));monthly=[[m,b,tm.get((m,b),(0,0))[0],tm.get((m,b),(0,0))[1],*sm.get((m,b),(0,0,0))] for m,b in keys]
summary=sheet('Monthly Summary',['Month','Branch','Transactions','Revenue (R)','Requests','Closed','Within SLA'],monthly,20,'#24745C')
summary.get_range(f'D2:D{len(monthly)+1}').set_number_format('"R" #,##0.00')
# Selector-based dashboard. SUMIFS conditions use '*' wildcard for all branches/months by treating source labels as text.
dash=wb.worksheets.add('Interactive Dashboard');dash.tab_color='#17365D'
dash.get_range('A1:H2').format={'fill':'#17365D','font':{'bold':True,'color':'#FFFFFF'},'row_height':28}
dash.get_range('A1').values=[['MAVUNO | BUSINESS INTELLIGENCE']]
dash.get_range('A2').values=[['INTERACTIVE EXECUTIVE REPORTING']]
dash.get_range('A4').values=[['BRANCH']];dash.get_range('D4').values=[['REPORTING MONTH']]
dash.get_range('B4').values=[['All Branches']];dash.get_range('E4').values=[['All Months']]
dash.get_range('B4').data_validation={'rule':{'type':'list','values':['All Branches','Johannesburg','Cape Town','Durban']}}
months=sorted(set(m for m,b in keys))
dash.get_range('E4').data_validation={'rule':{'type':'list','values':['All Months']+months}}
dash.get_range('A6:B6').values=[['KPI','VALUE']]
dash.get_range('A7:A12').values=[['Total Revenue (R)'],['Transactions'],['Service Requests'],['Closed Requests'],['Within 3-Day SLA'],['SLA Compliance']]
last=len(monthly)+1
br=f'IF($B$4="All Branches","*",$B$4)';mo=f'IF($E$4="All Months","*",$E$4)'
def sum_metric(col):return f'SUMIFS(\'Monthly Summary\'!${col}$2:${col}${last},\'Monthly Summary\'!$B$2:$B${last},{br},\'Monthly Summary\'!$A$2:$A${last},{mo})'
for row,col in [(7,'D'),(8,'C'),(9,'E'),(10,'F'),(11,'G')]:dash.get_range(f'B{row}').formulas=[[f'={sum_metric(col)}']]
dash.get_range('B12').formulas=[['=IF(B9=0,0,B11/B9)']]
dash.get_range('B7').set_number_format('"R" #,##0.00');dash.get_range('B12').set_number_format('0.0%')
dash.get_range('A15').values=[['BRANCH PERFORMANCE']]
dash.get_range('A16:D16').values=[['Branch','Revenue (R)','Transactions','Requests']]
for idx,name in enumerate(['Johannesburg','Cape Town','Durban'],17):
 dash.get_range(f'A{idx}').values=[[name]]
 for col,source in [('B','D'),('C','C'),('D','E')]:
  dash.get_range(f'{col}{idx}').formulas=[[f'=IF(OR($B$4="All Branches",$B$4=A{idx}),SUMIFS(\'Monthly Summary\'!${source}$2:${source}${last},\'Monthly Summary\'!$B$2:$B${last},A{idx},\'Monthly Summary\'!$A$2:$A${last},{mo}),0)']]
dash.get_range('B17:B19').set_number_format('"R" #,##0.00')
dash.get_range('A22').values=[['REFRESH: Run python refresh.py, then reopen this workbook. Select filters above.']]
dash.get_range('A23').values=[['All customer email addresses are fictional samples; no real mailbox ownership is implied.']]
dash.get_range('A1:H24').format.column_width=20
dash.get_range('A:A').format.column_width=31;dash.get_range('B:B').format.column_width=24
dash.get_range('A6:B6').format={'fill':'#24745C','font':{'bold':True,'color':'#FFFFFF'}}
dash.get_range('A16:D16').format={'fill':'#24745C','font':{'bold':True,'color':'#FFFFFF'}}
dash.get_range('B4').format={'fill':'#E7F2F6','font':{'bold':True,'color':'#17365D'}}
dash.get_range('E4').format={'fill':'#E7F2F6','font':{'bold':True,'color':'#17365D'}}
dash.freeze_panes.freeze_rows(2)
customers=con.execute('SELECT * FROM customers ORDER BY customer_id').fetchall();transactions=con.execute('SELECT * FROM transactions ORDER BY transaction_id').fetchall();requests=con.execute('SELECT * FROM service_requests ORDER BY request_id').fetchall()
sheet('Customers',['Customer ID','Customer Name','Branch','Email'],customers,24)
sheet('Transactions',['Transaction ID','Customer ID','Date','Amount (R)','Service'],transactions,23)
sheet('Service Requests',['Request ID','Customer ID','Opened','Resolved','Status','Service'],requests,23)
with (root/'output/load_summary.csv').open() as f:
 rows=list(csv.reader(f));sheet('Data Quality Audit',rows[0],[[v if i==0 else int(v) for i,v in enumerate(row)] for row in rows[1:]],25,'#7357A6')
with (root/'output/exceptions.csv').open() as f:
 rows=list(csv.reader(f));sheet('Rejected Records',rows[0],rows[1:],28,'#7357A6')
raw=[]
for file in sorted((root/'data/incoming').glob('transactions_*.csv')):
 with file.open(newline='') as f:
  rows=list(csv.reader(f));raw.extend(rows if not raw else rows[1:])
sheet('Raw Transactions',raw[0],raw[1:],24,'#7357A6')
wb.worksheets.set_active_worksheet('Interactive Dashboard')
SpreadsheetFile.export_xlsx(wb).save(str(root/'NM_Mavuno_Executive_Reporting.xlsx'))
print('Interactive Excel report created; months:',months,'monthly rows:',len(monthly),'customers:',len(customers))
