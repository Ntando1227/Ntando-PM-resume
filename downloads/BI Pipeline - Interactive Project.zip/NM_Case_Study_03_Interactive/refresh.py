"""One-command repeatable reporting refresh. Processes all incoming monthly CSV files."""
import subprocess,sys,pathlib
root=pathlib.Path(__file__).parent
for script in ("pipeline.py","build_report.py"):
 print(f"\n--- Running {script} ---",flush=True)
 subprocess.run([sys.executable,str(root/script)],check=True,cwd=root)
print("\nRefresh complete: output database, audits and Excel report updated.")
