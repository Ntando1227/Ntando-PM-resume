"""V8: configurable management alerts; no external email or network sends."""
import sqlite3,csv,pathlib,datetime,json
ROOT=pathlib.Path(__file__).parent;OUT=ROOT/'output';con=sqlite3.connect(OUT/'mavuno_reporting.sqlite');now=datetime.datetime.now(datetime.timezone.utc).isoformat()
rules={k:(v,bool(enabled)) for k,v,enabled in con.execute('SELECT * FROM alert_rules')}
alerts=[]
def flag(code,observed,message,severity='High'):
 threshold,enabled=rules[code]
 if enabled and observed>threshold:alerts.append((now,code,severity,round(observed,2),threshold,message))
raw,accepted=con.execute('SELECT COALESCE(SUM(raw_rows),0),COALESCE(SUM(accepted_rows),0) FROM file_manifest').fetchone();reject_pct=100*(raw-accepted)/raw if raw else 0
flag('HIGH_REJECTION_RATE',reject_pct,f'Data rejection rate {reject_pct:.1f}% exceeds threshold')
overdue=con.execute("SELECT COUNT(*) FROM service_requests WHERE status='Open' AND julianday('now')-julianday(opened_date)>3").fetchone()[0]
flag('OVERDUE_OPEN_REQUESTS',overdue,f'{overdue} open requests older than 3 days')
monthly=con.execute('SELECT substr(transaction_date,1,7),sum(amount) FROM transactions GROUP BY 1 ORDER BY 1 DESC LIMIT 2').fetchall()
if len(monthly)==2 and monthly[1][1]>0:
 decline=100*(monthly[1][1]-monthly[0][1])/monthly[1][1]
 flag('REVENUE_DECLINE_PCT',decline,f'Revenue declined {decline:.1f}% from {monthly[1][0]} to {monthly[0][0]}')
con.execute('DELETE FROM management_alerts WHERE run_at=?',(now,));con.executemany('INSERT INTO management_alerts VALUES(?,?,?,?,?,?)',alerts);con.commit()
with (OUT/'management_alerts.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['run_at','rule_code','severity','observed','threshold','message']);w.writerows(alerts)
with (OUT/'management_summary.md').open('w') as f:
 f.write('# Mavuno Management Refresh Summary\n\n'+f'Run: {now}\n\nRaw rows: {raw}; accepted file rows: {accepted}; rejection rate: {reject_pct:.2f}%\n\n')
 f.write(f'Open service requests beyond 3 days: {overdue}\n\n')
 f.write('## Alerts\n\n'+(''.join(f'- **{a[1]}**: {a[5]}\n' for a in alerts) if alerts else 'No thresholds exceeded.\n'))
 f.write('\nGenerated locally; no emails sent.\n')
print('Management alerts:',len(alerts));con.close()
