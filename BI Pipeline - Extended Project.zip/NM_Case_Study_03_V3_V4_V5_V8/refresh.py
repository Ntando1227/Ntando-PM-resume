"""One command: incremental ETL, rule alerts, refreshed Excel reporting snapshot."""
import subprocess,sys,pathlib
root=pathlib.Path(__file__).parent
for script in ('pipeline.py','alerts.py','build_report.py'):
 print('\n---',script,'---',flush=True)
 subprocess.run([sys.executable,str(root/script)],check=True,cwd=root)
print('Refresh completed. No email was sent; see output/management_summary.md.')
